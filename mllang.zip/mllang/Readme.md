# Usage
## build compiler to sm file
```
./compiler.py -g [path_to_input_file] [path_to_output_file]
./compiler.py -g '../examples/sample1.sm' 'build/compiler.scm'
```

## build tests run
```
./compiler.py -t 'runtests.scm'
```
